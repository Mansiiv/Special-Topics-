import { initTodoList, addTodo, toggleTodo, deleteTodo } from './todoList.js';
import { initAutocomplete } from './autocomplete.js';
import { initCategorySelect } from './category.js';

// Initialize the application
function initApp() {
    initTodoList();
    initAutocomplete();
    initCategorySelect();

    // Add event listener for the form submission
    const form = document.getElementById('todoForm');
    form.addEventListener('submit', handleFormSubmit);
}

/**
 * Handles the form submission
 * @param {Event} event - The submit event
 */
function handleFormSubmit(event) {
    event.preventDefault();
    const input = document.getElementById('todoInput');
    const dueDateInput = document.getElementById('dueDateInput');
    const categorySelect = document.getElementById('categorySelect');
    
    const todo = input.value.trim();
    const dueDate = dueDateInput.value;
    const category = categorySelect.value;

    if (todo) {
        addTodo(todo, dueDate, category);
        input.value = '';
        dueDateInput.value = '';
        categorySelect.selectedIndex = 0;
    }
}

// Make toggleTodo and deleteTodo available globally
window.toggleTodo = toggleTodo;
window.deleteTodo = deleteTodo;

// Run the application
initApp();
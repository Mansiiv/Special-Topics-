// Common todo tasks for autocomplete
const commonTasks = ['Buy groceries', 'Do laundry', 'Call mom', 'Pay bills', 'Go to gym'];

/**
 * Initializes the autocomplete functionality
 */
export function initAutocomplete() {
    const input = document.getElementById('todoInput');
    const autocompleteList = document.createElement('ul');
    autocompleteList.id = 'autocomplete-list';
    autocompleteList.style.display = 'none';
    input.parentNode.insertBefore(autocompleteList, input.nextSibling);

    input.addEventListener('input', function() {
        const inputValue = this.value.toLowerCase();
        autocompleteList.innerHTML = '';
        autocompleteList.style.display = 'none';

        if (inputValue.length > 0) {
            const matches = commonTasks.filter(task => task.toLowerCase().startsWith(inputValue));
            if (matches.length > 0) {
                autocompleteList.style.display = 'block';
                matches.forEach(match => {
                    const li = document.createElement('li');
                    li.textContent = match;
                    li.addEventListener('click', function() {
                        input.value = this.textContent;
                        autocompleteList.style.display = 'none';
                    });
                    autocompleteList.appendChild(li);
                });
            }
        }
    });
}
// Todo categories
const categories = ['Personal', 'Work', 'Shopping', 'Health'];

/**
 * Initializes the category select element
 */
export function initCategorySelect() {
    const categorySelect = document.getElementById('categorySelect');
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categorySelect.appendChild(option);
    });
}
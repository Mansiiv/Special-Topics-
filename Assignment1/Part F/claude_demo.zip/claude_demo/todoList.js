// Array to store all todos
let todos = [];

/**
 * Adds a new todo to the list
 * @param {string} text - The todo text
 * @param {string} dueDate - The due date of the todo
 * @param {string} category - The category of the todo
 */
export function addTodo(text, dueDate, category) {
    todos.push({ text, completed: false, dueDate, category });
    renderTodos();
}

/**
 * Renders all todos in the list
 */
function renderTodos() {
    const list = document.getElementById('todoList');
    list.innerHTML = '';
    todos.forEach((todo, index) => {
        const li = createTodoElement(todo, index);
        list.appendChild(li);
    });
}

/**
 * Creates a new todo list item element
 * @param {Object} todo - The todo object
 * @param {number} index - The index of the todo in the array
 * @returns {HTMLElement} The created list item element
 */
function createTodoElement(todo, index) {
    const li = document.createElement('li');
    li.innerHTML = `
        <span>${todo.text}</span>
        <span>${todo.dueDate ? `Due: ${todo.dueDate}` : ''}</span>
        <span>Category: ${todo.category}</span>
        <button onclick="toggleTodo(${index})">
            ${todo.completed ? 'Undo' : 'Complete'}
        </button>
        <button onclick="deleteTodo(${index})">Delete</button>
    `;
    if (todo.completed) {
        li.style.textDecoration = 'line-through';
    }
    return li;
}

/**
 * Toggles the completed status of a todo
 * @param {number} index - The index of the todo to toggle
 */
export function toggleTodo(index) {
    todos[index].completed = !todos[index].completed;
    renderTodos();
}

/**
 * Deletes a todo from the list
 * @param {number} index - The index of the todo to delete
 */
export function deleteTodo(index) {
    todos.splice(index, 1);
    renderTodos();
}

/**
 * Initializes the todo list functionality
 */
export function initTodoList() {
    renderTodos();
}
let expenses = [];
const participants = ['Alice', 'Bob', 'Charlie', 'David', 'Eve'];

// Load data from local storage
function loadData() {
    const storedExpenses = localStorage.getItem('expenses');
    if (storedExpenses) expenses = JSON.parse(storedExpenses);
}

// Save data to local storage
function saveData() {
    localStorage.setItem('expenses', JSON.stringify(expenses));
}

// Add a new expense
function addExpense(title, description, amount, payer, splitWith) {
    const newExpense = { 
        title, 
        description, 
        amount: parseFloat(amount), 
        payer, 
        splitWith,
        date: new Date().toISOString()
    };
    expenses.push(newExpense);
    saveData();
    updateExpenseHistory();
    updateSummary();
}

// Update the expense history in the UI
function updateExpenseHistory() {
    const historyList = document.getElementById('expense-history');
    historyList.innerHTML = '';
    expenses.slice().reverse().forEach((expense, index) => {
        const li = document.createElement('li');
        const date = new Date(expense.date);
        li.innerHTML = `
            <strong>${expense.title}</strong> - ${date.toLocaleDateString()}<br>
            ${expense.description}<br>
            Amount: $${expense.amount.toFixed(2)}<br>
            Paid by: ${expense.payer}<br>
            Split with: ${expense.splitWith.join(', ')}
        `;
        
        // Add delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.onclick = () => deleteExpense(expenses.length - 1 - index);
        li.appendChild(deleteBtn);
        
        historyList.appendChild(li);
    });
}

// Delete an expense
function deleteExpense(index) {
    expenses.splice(index, 1);
    saveData();
    updateExpenseHistory();
    updateSummary();
}

// Update the summary of who owes what
function updateSummary() {
    const balanceDiv = document.getElementById('balance');
    balanceDiv.innerHTML = '';

    if (expenses.length === 0) {
        balanceDiv.textContent = 'No expenses yet.';
        return;
    }

    const balances = {};
    participants.forEach(participant => {
        balances[participant] = 0;
    });

    expenses.forEach(expense => {
        balances[expense.payer] += expense.amount;
        const splitAmount = expense.amount / expense.splitWith.length;
        expense.splitWith.forEach(participant => {
            balances[participant] -= splitAmount;
        });
    });

    Object.entries(balances).forEach(([participant, balance]) => {
        const p = document.createElement('p');
        if (balance > 0) {
            p.textContent = `${participant} is owed $${balance.toFixed(2)}`;
        } else if (balance < 0) {
            p.textContent = `${participant} owes $${(-balance).toFixed(2)}`;
        } else {
            p.textContent = `${participant} is settled up`;
        }
        balanceDiv.appendChild(p);
    });
}

// Settle up function
function settleUp() {
    const balances = {};
    participants.forEach(participant => {
        balances[participant] = 0;
    });

    expenses.forEach(expense => {
        balances[expense.payer] += expense.amount;
        const splitAmount = expense.amount / expense.splitWith.length;
        expense.splitWith.forEach(participant => {
            balances[participant] -= splitAmount;
        });
    });

    const settleTransactions = [];
    const debtors = Object.entries(balances).filter(([_, balance]) => balance < 0);
    const creditors = Object.entries(balances).filter(([_, balance]) => balance > 0);

    debtors.sort((a, b) => a[1] - b[1]);
    creditors.sort((a, b) => b[1] - a[1]);

    let debtorIndex = 0;
    let creditorIndex = 0;

    while (debtorIndex < debtors.length && creditorIndex < creditors.length) {
        const [debtor, debtAmount] = debtors[debtorIndex];
        const [creditor, creditAmount] = creditors[creditorIndex];
        
        const settleAmount = Math.min(-debtAmount, creditAmount);
        
        settleTransactions.push({
            from: debtor,
            to: creditor,
            amount: settleAmount
        });

        balances[debtor] += settleAmount;
        balances[creditor] -= settleAmount;

        if (balances[debtor] === 0) debtorIndex++;
        if (balances[creditor] === 0) creditorIndex++;
    }

    displaySettleTransactions(settleTransactions);
}

// Display settle transactions in a modal
function displaySettleTransactions(transactions) {
    const modal = document.getElementById('settle-modal');
    const transactionsList = document.getElementById('settle-transactions');
    transactionsList.innerHTML = '';

    transactions.forEach(transaction => {
        const li = document.createElement('li');
        li.textContent = `${transaction.from} pays ${transaction.to} $${transaction.amount.toFixed(2)}`;
        transactionsList.appendChild(li);
    });

    modal.style.display = 'block';
}

// Initialize the application
function init() {
    loadData();
    updateExpenseHistory();
    updateSummary();

    const form = document.getElementById('expense-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const description = document.getElementById('description').value;
        const amount = document.getElementById('amount').value;
        const payer = document.querySelector('input[name="payer"]:checked').value;
        const splitWith = Array.from(document.querySelectorAll('input[name="split"]:checked')).map(cb => cb.value);

        if (title && description && amount && payer && splitWith.length > 0) {
            addExpense(title, description, amount, payer, splitWith);
            form.reset();
            // Re-check all checkboxes after form reset
            document.querySelectorAll('input[name="split"]').forEach(cb => cb.checked = true);
        }
    });

    const settleUpButton = document.getElementById('settle-up');
    settleUpButton.addEventListener('click', settleUp);

    const closeModalButton = document.getElementById('close-modal');
    closeModalButton.addEventListener('click', () => {
        document.getElementById('settle-modal').style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === document.getElementById('settle-modal')) {
            document.getElementById('settle-modal').style.display = 'none';
        }
    });
}

// Run the initialization function when the page loads
window.addEventListener('load', init);